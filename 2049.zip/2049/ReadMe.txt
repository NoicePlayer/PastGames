
For this to run properly for some reason it seems that you have to run it from powershell (with admin maybe)
with this command:

java -jar 2048.jar
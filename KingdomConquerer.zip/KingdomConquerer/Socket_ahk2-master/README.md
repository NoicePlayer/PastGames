# Socket_Ahkv2

Thanks to GeekDude for his work [here](https://github.com/G33kDude/Socket.ahk) and [here](https://www.autohotkey.com/boards/viewtopic.php?f=6&t=35120).  And Bentschi for his work [here](https://autohotkey.com/board/topic/94376-socket-class-%C3%BCberarbeitet/).

Please read the comments in both files detailed help.

Example is designed to work on the same machine, but IP addr:port can be modified as desired.

## To-DO
* Add Multicast functions.
